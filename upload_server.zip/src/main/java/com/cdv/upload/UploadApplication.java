package com.cdv.upload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadApplication {

    public static void main(String[] args) {
        SpringApplication.run(UploadApplication.class, args);
        //  启动打开默认浏览器访问
        try {
            Runtime.getRuntime().exec("cmd /c start http://localhost:7474/index.html");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
