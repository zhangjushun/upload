import{az as e,au as a,ar as r}from"./index.2294b439.js";const _={};function c(n,t){return r(),a("h1",null,"404\u9875\u9762")}var l=e(_,[["render",c]]);export{l as default};
